<script setup lang="ts">
import Navigation from "./components/Navigation.vue";

</script>

<template>
  <Navigation />
  <router-view />

</template>

<style lang="scss" src="@/assets/css/app.scss">

</style>
